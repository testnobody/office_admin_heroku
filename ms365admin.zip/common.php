<?php
error_reporting(0);
session_start();
require('function.php');
$config = require('config.php');
extract($config);